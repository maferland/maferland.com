# maferland.com — Design Handoff

> Designed in Claude · Ready to implement in Next.js  
> Last updated: June 2026

---

---

## What changed vs. maferland.com (live site)

Each entry below is a discrete implementation task. "Before" = current live site. "After" = this design. CSS values are exact — copy them directly.

---

### 1. Pulsing status dot

**Where:** Hero eyebrow, Pinpoint featured card, case study header, lab entry status badges, blog featured card  
**Before:** Static colored dot or no dot  
**After:** Dot with keyframe pulse animation

```css
@keyframes pulse {
  0%, 100% { opacity: 1; transform: scale(1); }
  50%       { opacity: 0.3; transform: scale(0.65); }
}
.dot-active    { width:6px; height:6px; border-radius:50%; background:#54e6a8; animation: pulse 2s infinite; }
.dot-exploring { width:6px; height:6px; border-radius:50%; background:#f0b35e; animation: pulse 2s infinite; }
.dot-graveyard { width:6px; height:6px; border-radius:50%; background:#5c6470; /* no animation */ }
```

---

### 2. Hero eyebrow

**Where:** Home page, above H1  
**Before:** Plain text  
**After:** Flex row with pulsing mint dot + "Frontend engineer · open to new roles" in JetBrains Mono 11.5px, mint color  

```html
<div style="display:inline-flex;align-items:center;gap:9px;font-family:'JetBrains Mono',monospace;font-size:11.5px;letter-spacing:0.04em;color:#54e6a8;margin-bottom:24px;">
  <span class="dot-active"></span>
  Frontend engineer · open to new roles
</div>
```

---

### 3. Terminal card (new component)

**Where:** Home page hero, right column  
**Before:** Not present  
**After:** Dark panel card with macOS traffic lights, monospace data rows, and a typewriter on the `build` row

**Card styles:**
```css
background: #131720;
border: 1px solid rgba(255,255,255,0.08);
border-radius: 14px;
box-shadow: 0 24px 50px -28px rgba(0,0,0,0.6);
```

**Typewriter:** JS setInterval at 85ms/char, cycles 3 phrases, 16-tick pause before erase:
```js
const words = ['products that ship.', 'the 50ms you don\'t notice.', 'small things, done right.'];
```

**Blinking cursor:**
```css
@keyframes blink { 50% { opacity: 0; } }
.cursor { animation: blink 1s step-end infinite; }
```

---

### 4. Pinpoint — featured hero card (home page)

**Where:** Top of selected work section  
**Before:** Pinpoint was one of 4 equal cards in a grid  
**After:** Full-width 2-col card (content left / stripe right), links to case study

**Key styles:**
```css
/* top accent line */
height: 1px; background: #54e6a8; opacity: 0.35;

/* hover lift */
transition: transform .2s, box-shadow .2s;
&:hover { transform: translateY(-3px); box-shadow: 0 20px 44px -22px rgba(0,0,0,0.6); }

/* decision quote — left border callout */
border-left: 2px solid #54e6a8;
padding: 9px 14px;
font-size: 13px; color: var(--muted);
```

**CTA:** Single `↗` glyph (not "view ↗" or "case study →"), links to `/work/pinpoint`

---

### 5. Work cards — consistent footer

**Where:** 3 smaller work cards (quebec.run, Bonne Nuit, Calm Cycle)  
**Before:** Footer row floated, inconsistent vertical position  
**After:** Card inner div is `display:flex; flex-direction:column`. Description has `flex:1` so footer always pins to bottom

```css
.card-inner { display: flex; flex-direction: column; flex: 1; padding: 18px 18px 20px; }
.card-desc  { flex: 1; margin: 0; } /* grows to push footer down */
.card-footer { margin-top: 14px; display: flex; justify-content: space-between; align-items: center; }
```

**Arrow convention:** `↗` = external link, `→` = internal page (Bonne Nuit uses `→`)

---

### 6. Also Building — card grid

**Where:** Home page section 02  
**Before:** List rows (name · description · ↗ platform)  
**After:** 3-column card grid

```css
display: grid;
grid-template-columns: repeat(3, 1fr);
gap: 14px;
```

**Each card:**
```css
display: flex; flex-direction: column; gap: 8px;
background: var(--panel); border: 1px solid var(--line);
border-radius: 12px; padding: 18px 18px 16px;
transition: border-color .2s;
&:hover { border-color: rgba(255,255,255,0.2); }
```

**Card anatomy (top to bottom):**
1. Name (700, 16px) + `↗` (accent, 14px) — space-between flex row
2. Description (13px, --muted, flex:1)
3. Platform badge (JetBrains Mono 10px, bordered pill, align-self: flex-start)

**Removed:** ClipShield. Now 5 tools: Burn · Relay · Snip · Differ · Tidy

---

### 7. Blog — featured card accent line

**Where:** Writing page, featured post card  
**Before:** 5px dashed stripe header (overwhelming)  
**After:** 1px solid accent line, 35% opacity — same as work cards

```css
height: 1px; background: #54e6a8; opacity: 0.35; grid-column: 1 / -1;
```

---

### 8. Blog — post category tags

**Where:** Writing page, all post entries  
**Before:** Plain mono text tag  
**After:** Pill badge with border

```css
font-family: 'JetBrains Mono', monospace;
font-size: 9.5px; color: var(--muted);
border: 1px solid rgba(255,255,255,0.10);
padding: 3px 8px; border-radius: 99px;
```

---

### 9. Blog — featured badge

**Before:** Bordered rectangle badge  
**After:** Pill with pulsing dot

```html
<span style="display:inline-flex;align-items:center;gap:6px;background:rgba(84,230,168,0.10);border:1px solid rgba(84,230,168,0.30);padding:4px 10px;border-radius:99px;font-family:'JetBrains Mono',monospace;font-size:10px;color:#54e6a8;">
  <span class="dot-active" style="width:5px;height:5px;"></span>featured
</span>
```

---

### 10. Nav — Lab tab added

**Before:** home / work / playground / writing  
**After:** home / work / playground / writing / **lab**

Route: `/lab`

---

### 11. Theme toggle

**Before:** Not present  
**After:** ◑ button in nav, right side, before CTA

**Behavior:** Swaps a set of CSS custom properties on the root element. Transition: `background .3s, color .3s` on all major elements. See full token table in the Design Tokens section.

```html
<button onClick={toggleTheme}>◐ {isDark ? 'light' : 'dark'}</button>
```

---

### 12. Case study pages — new (`/work/[slug]`)

**Before:** Basic text layout, README-style  
**After:** Decision Log layout. Full spec in the Case Study Page section above.

**Key new elements:**
- 1px accent top border on hero card (not a stripe)
- Build log: `display:grid; grid-template-columns:80px 1fr` per entry
- Key decisions: `border-left: 2px solid #54e6a8` (primary) / `border-left: 2px solid rgba(84,230,168,.3)` (secondary)
- "what surprised me" + "if I built it again": `border-left: 1px solid var(--line); padding-left: 16px`
- Status bar: pulsing dot + label left, CTA right

---

### 13. Lab index — copy + graveyard entry

**Before:** Single entry, "Ideas I'm exploring, building, parking, or killing"  
**After:**

Page headline: `"Ideas, alive and otherwise."`  
Sub: `"Most die at the research gate. I log them all anyway — the graveyard is half the point."`

**Graveyard card treatment:**
```css
opacity: 0.72;
/* title color: var(--muted) instead of var(--text) */
/* status dot: #5c6470, no animation */
```

Hover: `opacity: 1; transform: translateY(-2px)`

---

### 14. Lab detail pages — new (`/lab/[slug]`)

**Before:** Not present  
**After:** Two variants (exploring / graveyard). Full spec in the Lab Detail Page section above.

**Status badge pill styles:**
```css
/* exploring */
background: rgba(240,179,94,0.12); border: 1px solid rgba(240,179,94,0.3); color: #f0b35e;

/* graveyard */
background: rgba(92,100,112,0.15); border: 1px solid rgba(92,100,112,0.3); color: #5c6470;
```

**Graveyard text contrast:** Use `var(--body)` (#c3cad4 dark) for body copy — not `var(--faint)`. Faint is only for dates and metadata.

---

### 15. Favicon (new)

```html
<link rel="icon" href="/favicon.png" type="image/png">
```

64×64px, mint (#54e6a8) rounded square (radius 14px), mono "m" in #07120d at 36px bold. File: `favicon.png` in this package.



---

## Case Study Page (/work/[slug])

### Concept: Decision Log
The case study reads like the engineer's actual working artifact — not a polished portfolio piece. Structure signals high agency: first-person ownership, real decisions with tradeoffs, honest reflection, and a "what I cut" beat that shows judgment.

### Layout

**Hero card** (full-width panel, 16px radius):
- Thin dashed accent stripe across the top (repeating-linear-gradient, 2px dash / 12px gap)
- Tag row: platform tag + pulsing status dot + status label
- H1: 64px weight 800, tracking -0.04em
- Subtitle: 22px --body, max-width 580px
- Metadata strip (border-top): role / stack / shipped date / link — 28px padding-right per col, 1px --line dividers

**Visual zone** (240px, stripe bg):
- Drop a real screenshot or annotated diagram here
- The mock annotation UI (faux browser + pin card) is Pinpoint-specific — adapt per project

**Content** (max-width 720px, 52px top padding):

1. Hook lede — 22px 600, the problem in 2-3 sharp sentences. No section header.
2. Build log — mono section header + rule. 80px date col / 1fr content grid. Each entry: accent mono label + 14.5px prose. Separated by 1px border-bottom. First-person, specific, shows real decisions.
3. Key decisions — 2-3 callout blocks. Primary: 2px solid accent left border. Secondary: 2px rgba(accent,.3) left border. Panel bg, rounded right corners. Mono label + prose body.
4. What surprised me — 1px --line left border, 15px --muted prose. Only the builder can write this. Credibility anchor.
5. If I built it again — same treatment. One honest sentence.
6. Status bar — panel bg, pulsing dot + status label left / CTA right.
7. Prev/next nav — mono 12px --faint, space-between.

### High-agency signals (structural, not copy)
- "sole designer + engineer" in role — ownership language
- Build log format implies process and decision-tracking
- "what I cut" entries shown alongside what shipped
- "if I built it again" section — only confident engineers reflect publicly
- Specific dates in the log (fill in real ones)

### Status color system
- active/public:  #54e6a8 (mint), pulse animation
- exploring:      #f0b35e (amber), pulse animation
- graveyard:      #5c6470 (faint), no animation

---

## Lab Detail Page (/lab/[slug])

### Concept: Honest idea log
Not a case study. The status badge leads the page (not the title). Structure shows epistemic honesty: what's known, what isn't, what needs validating before writing a line of code.

### Layout

**Header card** (full-width panel):
- Status badge pill: amber for exploring, mint for alive, faint for graveyard
- H1: 56px 800
- Subtitle: 20px --body, max-width 560px
- Metadata: logged date / platform / gate status

**Content** (max-width 720px):

1. Hook lede — 21px 600, the idea in human terms
2. The itch — where the friction came from. Specific beats generic.
3. Research gate — amber section header. Question cards (20px "?" col / 1fr): bold question + what you need to validate. Most differentiating section — shows you think before you build.
4. Signal so far — 2-col grid: "know" (mint) / "don't know" (faint). Epistemic honesty at a glance.
5. Next step — amber-tinted border card. One concrete next action.

### Graveyard variant
Same layout, different treatment:
- Status badge: #5c6470 faint, no pulse
- Replace research gate + signal with a single "why I killed it" callout (2px faint left border)
- Title and subtitle in muted colors
- Graveyard is the most credible part of the lab — shows decision-making, not just project-starting

### New files in this package
- Case Study Design.dc.html — full Pinpoint case study (open in browser to interact)
- Lab Detail Design.dc.html — Hearth lab detail + graveyard variant reference section
- screenshots/06-case-study.png — case study hero
- screenshots/07-lab-detail.png — lab detail hero


---

## Updates — Jul 2026

### New pages added to prototype (Maferland Site.dc.html)
All pages are fully wired — navigate between them inside the file.

| Page | Nav path |
|---|---|
| Home | default |
| Playground | nav → playground |
| Writing | nav → writing |
| Lab | nav → lab |
| Lab Detail (Hearth) | lab → Hearth card |
| Lab Graveyard (Tempo) | lab → Tempo card |
| Case Study (Pinpoint) | home → Pinpoint featured card |

### Favicon
- `favicon.png` — 64×64 mint rounded square with mono "m" glyph
- Reference color: #54e6a8 bg / #07120d text
- Add to `<head>`: `<link rel="icon" href="/favicon.png" type="image/png">`

### Also Building — ClipShield removed
Now 5 tools: Burn · Relay · Snip · Differ · Tidy

### Graveyard page contrast
Text bumped from --faint to --body/--muted for readability. Status badge stays faint (intentional muted treatment for dead ideas).

### Content still needed from Marc-Antoine
- Bonne Nuit one-liner (replace placeholder in work card)
- Real GitHub repo names for: Burn, Relay, Snip, Differ, Tidy
- Pinpoint case study: real dates in build log, "what surprised me", "if I built it again"
- Keyhole case study (details not yet shared)
